import psycopg2

# Database connection setup
def connect_to_db():
    return psycopg2.connect(
        dbname="Library",
        user="postgres",
        password="Misba@123",
        host="localhost",
        port="5432"
    )

# Initialize the database
def initialize_database():
    try:
        conn = connect_to_db()
        cursor = conn.cursor()

        # Create users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(255) UNIQUE NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                age INT NOT NULL,
                phone_number VARCHAR(20) UNIQUE NOT NULL,
                subscription_type VARCHAR(10) NOT NULL,
                subscription_start DATE NOT NULL,
                subscription_expiry DATE NOT NULL
            );
        """)

        # Create books table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS books (
                id SERIAL PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                author VARCHAR(255) NOT NULL,
                genre VARCHAR(100) NOT NULL,
                category VARCHAR(50) NOT NULL,
                publication_year INT NOT NULL,
                rating DECIMAL(3,2) CHECK (rating >= 0 AND rating <= 5),
                access_type VARCHAR(10) NOT NULL,
                book_link VARCHAR(2083) NOT NULL,
                summary TEXT NOT NULL
            );
        """)

        # Create subscriptions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS subscriptions (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(255) NOT NULL,
                plan VARCHAR(10) NOT NULL,
                start_date DATE NOT NULL,
                expiry_date DATE NOT NULL,
                amount_paid DECIMAL(10,2) NOT NULL,
                payment_status VARCHAR(10) NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """)

        # Create book_reviews table (Fix foreign key reference, remove UNIQUE on user_id)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS book_reviews (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(255) NOT NULL,
                book_id INT NOT NULL,
                rating DECIMAL(3,2) CHECK (rating >= 0 AND rating <= 5),
                review TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
            );
        """)

        # Create bookmarks table (Fix foreign key reference, remove UNIQUE on user_id)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bookmarks (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(255) NOT NULL,
                book_id INT NOT NULL,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
            );
        """)

        # Create reading_progress table (Fix foreign key reference, remove UNIQUE on user_id)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reading_progress (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(255) NOT NULL,
                book_id INT NOT NULL,
                last_page INT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
            );
        """)

        # Create audiobooks table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audiobooks (
                id SERIAL PRIMARY KEY,
                book_id INT NOT NULL,
                narrator VARCHAR(255) NOT NULL,
                duration TIME NOT NULL,
                audio_link VARCHAR(2083) NOT NULL,
                FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
            );
        """)


        conn.commit()
        print("✅ Tables created successfully.")

    except Exception as e:
        print(f"❌ Error creating tables: {e}")

    finally:
        conn.close()

# Run the database initialization
if __name__ == "__main__":
    initialize_database()

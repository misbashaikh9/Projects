import psycopg2
from datetime import datetime, timedelta

# Database connection setup
def connect_to_db():
    return psycopg2.connect(
        dbname="Library",
        user="postgres",
        password="Misba@123",
        host="localhost",
        port="5432"
    )

# Display subscription plans
def show_plans():
    print("\n📜 Subscription Plans:")
    print("=" * 40)
    print("1️⃣ Basic Plan - ₹199/month")
    print("   ✅ Access to e-books only")
    print("\n2️⃣ Premium Plan - ₹499/month")
    print("   ✅ Access to e-books + audiobooks")
    print("=" * 40)

# Simulate payment process
def process_payment(amount):
    print(f"\n💳 Processing payment of ₹{amount}...")
    confirmation = input("Confirm payment? (yes/no): ").strip().lower()
    return confirmation == "yes"

# Purchase subscription
def buy_subscription(user_id):
    show_plans()
    
    choice = input("Select a plan (1 for Basic, 2 for Premium): ").strip()
    
    if choice == "1":
        plan = "basic"
        amount = 199
    elif choice == "2":
        plan = "premium"
        amount = 499
    else:
        print("❌ Invalid choice. Exiting...")
        return None, None  # Ensure function always returns two values

    # Simulate payment
    if not process_payment(amount):
        print("❌ Payment canceled.")
        return None, None  # Ensure consistent return on failure

    return plan, amount  # Only return the selected plan and amount, no database operations

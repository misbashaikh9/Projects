import psycopg2
import hashlib
import os

# ANSI Escape Codes for Colors
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
BOLD = "\033[1m"
RESET = "\033[0m"

def connect_to_db():
    return psycopg2.connect(
        dbname="Library",
        user="postgres",
        password="Misba@123",
        host="localhost",
        port="5432"
    )

def hash_password(password):
    """Hash the password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def clear_screen():
    """Clear the terminal screen"""
    os.system("cls" if os.name == "nt" else "clear")

def user_login():
    """Authenticate user by checking email and password from the database"""
    clear_screen()
    print(f"{CYAN}{'='*40}")
    print(f"{BOLD}📚 Welcome to the E-Library Login Portal {RESET}")
    print(f"{CYAN}{'='*40}{RESET}\n")

    conn = connect_to_db()
    cursor = conn.cursor()

    email = input(f"{YELLOW}📧 Enter email: {RESET}")
    password = input(f"{YELLOW}🔑 Enter password: {RESET}")
    hashed_password = hash_password(password)

    # Check if user exists with given email & password
    cursor.execute("SELECT user_id, email, subscription_type FROM users WHERE email = %s AND password_hash = %s", 
                   (email, hashed_password))
    user = cursor.fetchone()

    conn.close()

    if user:
        user_id, email, subscription_type = user
        clear_screen()
        print(f"{GREEN}{'='*45}")
        print(f"✅ {BOLD}Login successful!{RESET}{GREEN} Welcome, {email}.")
        print(f"🎟️ Subscription Type: {BOLD}{subscription_type.upper()}{RESET}")
        print(f"{GREEN}{'='*45}{RESET}\n")
        return user  # Returns user details (user_id, email, subscription_type)
    else:
        print(f"\n{RED}❌ Invalid email or password! Please try again.{RESET}\n")
        return None

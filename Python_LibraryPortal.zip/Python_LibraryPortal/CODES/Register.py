import psycopg2
import hashlib
import re
import os
import getpass  # For hidden password input
import Subscription as sb

# ANSI Escape Codes for Colors
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
BOLD = "\033[1m"
RESET = "\033[0m"

def connect_to_db():
    return psycopg2.connect(
        dbname="Library",
        user="postgres",
        password="Misba@123",
        host="localhost",
        port="5432"
    )

def hash_password(password):
    """Hash the password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def is_valid_email(email):
    """Check if the email is in a valid format."""
    email_pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(email_pattern, email)

def is_valid_phone(phone_number):
    """Check if the phone number contains only digits and has 10-15 digits."""
    phone_pattern = r"^\d{10,15}$"
    return re.match(phone_pattern, phone_number)

def is_valid_password(password):
    """Check if password is at least 8 characters long and contains at least one special character."""
    password_pattern = r"^(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$"
    return re.match(password_pattern, password)

def clear_screen():
    """Clear the terminal screen"""
    os.system("cls" if os.name == "nt" else "clear")

def user_register():
    """Register a new user with input validation and subscription selection."""
    clear_screen()
    print(f"{CYAN}{'='*50}")
    print(f"{BOLD}📚 Welcome to E-Library - User Registration{RESET}")
    print(f"{CYAN}{'='*50}{RESET}\n")

    conn = connect_to_db()
    cursor = conn.cursor()

    try:
        # ✅ **Check if user already exists**
        while True:
            user_id = input(f"{YELLOW}👤 Enter user ID: {RESET}")
            cursor.execute("SELECT user_id FROM users WHERE user_id = %s", (user_id,))
            if cursor.fetchone():
                print(f"{RED}❌ User ID already exists! Choose a different one.{RESET}")
            else:
                break

        # ✅ **Validate email format**
        while True:
            email = input(f"{YELLOW}📧 Enter email: {RESET}")
            if is_valid_email(email):
                break
            print(f"{RED}❌ Invalid email format! Please enter a valid email (e.g., example@mail.com).{RESET}")

        # ✅ **Validate phone number format**
        while True:
            phone_number = input(f"{YELLOW}📞 Enter phone number: {RESET}")
            if is_valid_phone(phone_number):
                break
            print(f"{RED}❌ Invalid phone number! It should contain only digits (10-15 characters).{RESET}")

        # ✅ **Validate password format & mask input**
        while True:
            password = getpass.getpass(f"{YELLOW}🔑 Enter password (hidden): {RESET}")  # Hides password input
            if is_valid_password(password):
                break
            print(f"{RED}❌ Invalid password! It must be at least 8 characters long and contain at least one special character (!@#$%^&*).{RESET}")

        hashed_password = hash_password(password)

        # ✅ **Validate age input**
        while True:
            try:
                age = int(input(f"{YELLOW}🎂 Enter age: {RESET}"))
                if age <= 0:
                    raise ValueError
                break
            except ValueError:
                print(f"{RED}❌ Invalid age! Please enter a positive number.{RESET}")

        # ✅ **Ask for Subscription After Validating User Data**
        subscription_type, amount = sb.buy_subscription(user_id)

        if not subscription_type or not amount:  # If user cancels, stop registration
            print(f"{RED}❌ Registration canceled due to payment failure.{RESET}")
            return

        # ✅ **Insert user with subscription data**
        cursor.execute("""
            INSERT INTO users (user_id, email, phone_number, password_hash, age, subscription_type, subscription_start, subscription_expiry) 
            VALUES (%s, %s, %s, %s, %s, %s, CURRENT_DATE, CURRENT_DATE + INTERVAL '30 days')
        """, (user_id, email, phone_number, hashed_password, age, subscription_type))

        # ✅ **Insert into subscriptions table**
        cursor.execute("""
            INSERT INTO subscriptions (user_id, plan, start_date, expiry_date, amount_paid, payment_status)
            VALUES (%s, %s, CURRENT_DATE, CURRENT_DATE + INTERVAL '30 days', %s, 'completed')
        """, (user_id, subscription_type, amount))

        conn.commit()
        clear_screen()
        print(f"{GREEN}{'='*50}")
        print(f"✅ {BOLD}Registration Successful!{RESET}{GREEN} Welcome, {email}.")
        print(f"🎟️ Subscription Type: {BOLD}{subscription_type.upper()}{RESET}")
        print(f"{GREEN}{'='*50}{RESET}\n")

    except psycopg2.IntegrityError as e:
        conn.rollback()
        print(f"{RED}❌ Error: {e}{RESET}")

    finally:
        cursor.close()
        conn.close()

import psycopg2
from datetime import datetime

def connect_to_db():
    return psycopg2.connect(
        dbname="Library",
        user="postgres",
        password="Misba@123",
        host="localhost",
        port="5432"
    )

def show_books_by_category(category):
    """Display books by category with book ID first and book link last."""
    conn = connect_to_db()
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, name, author, genre, publication_year, rating, summary, book_link FROM books WHERE category = %s", (category,))
    books = cursor.fetchall()
    
    if books:
        print(f"\n📚 Books in {category} Category:")
        for book in books:
            print("\n🆔 Book ID:", book[0])
            print("📖 Name:", book[1])
            print("✍️ Author:", book[2])
            print("📚 Genre:", book[3])
            print("📅 Published:", book[4])
            print("⭐ Rating:", book[5])
            print("📝 Summary:", book[6])
            print("🔗 Link:", book[7])
            print("-" * 30)  # Separator for better readability
    else:
        print("❌ No books found in this category!")
    
    conn.close()

def show_audiobooks():
    """Display available audiobooks (for premium users) with book ID first and audio link last."""
    conn = connect_to_db()
    cursor = conn.cursor()
    
    cursor.execute("SELECT book_id, name, author, narrator, duration, audio_link FROM audiobooks JOIN books ON audiobooks.book_id = books.id")
    audiobooks = cursor.fetchall()
    
    if audiobooks:
        print("\n🎧 Available Audiobooks:")
        for book in audiobooks:
            print("\n🆔 Book ID:", book[0])
            print("📖 Name:", book[1])
            print("✍️ Author:", book[2])
            print("🎙️ Narrator:", book[3])
            print("⏳ Duration:", book[4])
            print("🔗 Audio Link:", book[5])
            print("-" * 30)  # Separator for better readability
    else:
        print("❌ No audiobooks available!")
    
    conn.close()

def add_book_review(user_id, book_id):
    """Allow the user to add a book review."""
    rating = input("⭐ Enter rating (0-5): ")
    review = input("📝 Write your review: ")

    conn = connect_to_db()
    cursor = conn.cursor()

    try:
        # Check if the book ID exists
        cursor.execute("SELECT COUNT(*) FROM books WHERE id = %s", (book_id,))
        book_exists = cursor.fetchone()[0]

        if book_exists == 0:
            print("❌ Book ID not found! Please enter a valid book ID.")
            return

        # Insert the review
        cursor.execute("""
            INSERT INTO book_reviews (user_id, book_id, rating, review, created_at)
            VALUES (%s, %s, %s, %s, %s)
        """, (user_id, book_id, rating, review, datetime.now()))

        conn.commit()
        print("✅ Review added successfully!")

    except psycopg2.Error as e:
        print("❌ Database error:", e)

    finally:
        cursor.close()
        conn.close()

def add_bookmark(user_id, book_id):
    """Allow the user to bookmark a book."""
    conn = connect_to_db()
    cursor = conn.cursor()

    try:
        # Check if the book ID exists
        cursor.execute("SELECT COUNT(*) FROM books WHERE id = %s", (book_id,))
        book_exists = cursor.fetchone()[0]

        if book_exists == 0:
            print("❌ Book ID not found! Please enter a valid book ID.")
            return

        # Insert the bookmark
        cursor.execute("""
            INSERT INTO bookmarks (user_id, book_id, added_at)
            VALUES (%s, %s, %s)
        """, (user_id, book_id, datetime.now()))

        conn.commit()
        print("✅ Bookmarked successfully!")

    except psycopg2.Error as e:
        print("❌ Database error:", e)

    finally:
        cursor.close()
        conn.close()

def update_reading_progress(user_id, book_id):
    """Allow the user to update their reading progress."""
    last_page = input("📖 Enter last page you read: ")

    # Ensure last_page is a valid integer
    if not last_page.isdigit() or int(last_page) <= 0:
        print("❌ Invalid page number! Please enter a positive number.")
        return

    conn = connect_to_db()
    cursor = conn.cursor()

    try:
        # Check if the book ID exists
        cursor.execute("SELECT COUNT(*) FROM books WHERE id = %s", (book_id,))
        book_exists = cursor.fetchone()[0]

        if book_exists == 0:
            print("❌ Book ID not found! Please enter a valid book ID.")
            return

        # Insert or update reading progress
        cursor.execute("""
            INSERT INTO reading_progress (user_id, book_id, last_page, updated_at)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (user_id, book_id) 
            DO UPDATE SET last_page = EXCLUDED.last_page, updated_at = EXCLUDED.updated_at
        """, (user_id, book_id, last_page, datetime.now()))

        conn.commit()
        print("✅ Reading progress updated successfully!")

    except psycopg2.Error as e:
        print("❌ Database error:", e)

    finally:
        cursor.close()
        conn.close()

def show_bookmarked_books(user_id):
    """Display books that the user has bookmarked."""
    conn = connect_to_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT books.id, books.name, books.author, books.genre, books.publication_year, books.rating, books.book_link
        FROM bookmarks
        JOIN books ON bookmarks.book_id = books.id
        WHERE bookmarks.user_id = %s
    """, (user_id,))
    
    bookmarked_books = cursor.fetchall()
    
    if bookmarked_books:
        print("\n📌 Your Bookmarked Books:")
        for book in bookmarked_books:
            print("\n🆔 Book ID:", book[0])
            print("📖 Name:", book[1])
            print("✍️ Author:", book[2])
            print("📚 Genre:", book[3])
            print("📅 Published:", book[4])
            print("⭐ Rating:", book[5])
            print("🔗 Link:", book[6])
            print("-" * 30)  # Separator for better readability
    else:
        print("❌ No bookmarked books found!")
    
    conn.close()

def show_reading_progress(user_id):
    """Display the user's saved reading progress."""
    conn = connect_to_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT books.id, books.name, books.author, reading_progress.last_page, reading_progress.updated_at
        FROM reading_progress
        JOIN books ON reading_progress.book_id = books.id
        WHERE reading_progress.user_id = %s
    """, (user_id,))
    
    progress = cursor.fetchall()
    
    if progress:
        print("\n📖 Your Reading Progress:")
        for book in progress:
            print("\n🆔 Book ID:", book[0])
            print("📖 Name:", book[1])
            print("✍️ Author:", book[2])
            print("📄 Last Page Read:", book[3])
            print("🕒 Last Updated:", book[4])
            print("-" * 30)  # Separator for better readability
    else:
        print("❌ No reading progress found!")
    
    conn.close()
def book_menu(user_id, subscription_type):
    """Display the book menu after user login."""
    while True:
        print("\n📚 Book Section")
        print("1️⃣ View & Read E-Books")
        if subscription_type.lower() == "premium":  
            print("2️⃣ Listen to Audiobooks")
        print("3️⃣ Bookmark a Book")
        print("4️⃣ View Bookmarked Books")
        print("5️⃣ Review a Book")
        print("6️⃣ Update Reading Progress")
        print("7️⃣ View Reading Progress")  # NEW OPTION
        print("8️⃣ Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            print("\n📂 Choose a category:")
            categories = ["Love", "Kids", "Fiction", "Self-Help", "Science"]
            for i, cat in enumerate(categories, 1):
                print(f"{i}. {cat}")

            category_choice = input("Enter category number: ")
            if category_choice.isdigit() and 1 <= int(category_choice) <= len(categories):
                show_books_by_category(categories[int(category_choice) - 1])
            else:
                print("❌ Invalid choice!")

        elif choice == "2" and subscription_type.lower() == "premium":
            show_audiobooks()

        elif choice == "3":
            book_id = input("📌 Enter book ID to bookmark: ")
            add_bookmark(user_id, book_id)

        elif choice == "4":
            show_bookmarked_books(user_id)

        elif choice == "5":
            book_id = input("📌 Enter book ID to review: ")
            add_book_review(user_id, book_id)

        elif choice == "6":
            book_id = input("📌 Enter book ID to update progress: ")
            update_reading_progress(user_id, book_id)

        elif choice == "7":
            show_reading_progress(user_id)  # NEW FUNCTION CALL

        elif choice == "8":
            print("👋 Exiting book menu!")
            break

        else:
            print("❌ Invalid choice! Try again.")

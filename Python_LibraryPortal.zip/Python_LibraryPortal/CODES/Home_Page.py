import Login
import Register
import Connection_db as cnn
from book_audio import book_menu  # Import book_menu function
from colorama import Fore, Style, init

# Initialize colorama (for Windows compatibility)
init(autoreset=True)

def main():
    while True:
        print(Fore.CYAN + "\n📖 Welcome to the E-Library!" + Style.RESET_ALL)
        print(Fore.YELLOW + "=" * 40)
        print(Fore.GREEN + "1️⃣  Login")
        print(Fore.BLUE + "2️⃣  Register")
        print(Fore.RED + "3️⃣  Exit")
        print(Fore.YELLOW + "=" * 40)

        choice = input(Fore.MAGENTA + "📌 Enter your choice: " + Style.RESET_ALL)

        if choice == "1":
            user = Login.user_login()
            if user:
                user_id, email, subscription_type = user  # Unpack user details
                print(Fore.GREEN + f"✅ Welcome, {email}! 📚 Happy reading!" + Style.RESET_ALL)
                
                # Call book_menu with user_id and subscription_type
                book_menu(user_id, subscription_type)

        elif choice == "2":
            Register.user_register()
        elif choice == "3":
            print(Fore.RED + "👋 Goodbye! Keep Reading! 📚✨" + Style.RESET_ALL)
            break
        else:
            print(Fore.RED + "❌ Invalid choice! Please try again." + Style.RESET_ALL)

if __name__ == "__main__":
    cnn.initialize_database()
    main()

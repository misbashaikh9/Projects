    let cart = [];

    function updateCartUI() {
        const cartItemsContainer = document.getElementById("cart-items");
        const cartTotalItems = document.getElementById("cart-total-items");
        const cartTotalPrice = document.getElementById("cart-total-price");
        const cartEmptyText = document.getElementById("cart-empty");
    
        cartItemsContainer.innerHTML = "";
        let totalItems = 0, totalPrice = 0;
    
        if (cart.length === 0) {
            cartEmptyText.style.display = "block";
        } else {
            cartEmptyText.style.display = "none";
        }
    
        cart.forEach((item, index) => {
            totalItems += item.quantity;
            totalPrice += item.price * item.quantity;
            let listItem = document.createElement("li");
            listItem.className = "list-group-item d-flex justify-content-between align-items-center";
            listItem.innerHTML = `
                ${item.name} (x${item.quantity})
                <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                <button class="btn btn-sm btn-danger" onclick="removeFromCart(${index})">X</button>
            `;
            cartItemsContainer.appendChild(listItem);
        });
    
        cartTotalItems.textContent = totalItems;
        cartTotalPrice.textContent = totalPrice.toFixed(2);
    }
    function removeFromCart(index) {
        cart.splice(index, 1);
        saveCart();
        updateCartUI();
    }
    function saveCart() {
        localStorage.setItem("cart", JSON.stringify(cart));
    }
    
    function loadCart() {
        let savedCart = localStorage.getItem("cart");
        if (savedCart) {
            cart = JSON.parse(savedCart);
            updateCartUI();
        }
    }
    function addToCart(name, price) {
        let existingItem = cart.find(item => item.name === name);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ name, price, quantity: 1 });
        }
        saveCart();
        updateCartUI();
        // Show alert when item is added
       alert(`${name} has been added to your cart!`);
    }
    document.addEventListener("DOMContentLoaded", function() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        document.getElementById("cart-count").textContent = cart.length;
    });
    
    // Load cart on page load
    document.addEventListener("DOMContentLoaded", loadCart);  
    
import serial
import numpy as np
import matplotlib.pyplot as plt
import time

#Replace 'COM18' with the actual port connected
ser = serial.Serial('COM18', 115200, timeout = 1)

def read_frame():
    line = serial.readline().decode('utf-8').strip()
    try:
        data = list(map(float, line.split(', ')))
        if len(data) == 32*24:
            return np.array(data).reshape((24, 32))
    except ValueError:
        pass
    return None
    
#Iniialize the plot
plt.ion()
fid, ax = plt.subplots()
im = ax.imshow(np.zeros((24,32)), cmap='jet', vmin=25, vmax=40)
#you can change cmap for various colour schemes and vmin and vmax for different temperature ranges
plt.colorbar(im)
ply.title("MLX90640 Thermal Image")

#Main loop to read and update the Image
while True:
    frame = read_frame()
    if frame is not None:
        im.set_array(frame)
        plt.draw()
        plt.pause(0.01)
        #Short pause for real time update
    else:
        time.sleep(0.1)
        #Wait a bit before retrying if no valid frame is received
